#include <iostream>
#include <queue>
using namespace std;

class StackUsingTwoQueues {
    queue<int> q1, q2;

public:
    // Push operation
    void push(int x) {
        // Step 1: Push new element into q2
        q2.push(x);

        // Step 2: Push all elements of q1 into q2
        while (!q1.empty()) {
            q2.push(q1.front());
            q1.pop();
        }

        // Step 3: Swap names of q1 and q2
        swap(q1, q2);

        cout << x << " pushed into stack.\n";
    }

    // Pop operation
    void pop() {
        if (q1.empty()) {
            cout << "Stack Underflow! Nothing to pop.\n";
            return;
        }
        cout << q1.front() << " popped from stack.\n";
        q1.pop();
    }

    // Peek operation
    void peek() {
        if (q1.empty()) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "Top element: " << q1.front() << endl;
    }

    // Check if stack is empty
    bool isEmpty() {
        return q1.empty();
    }

    // Display stack elements
    void display() {
        if (q1.empty()) {
            cout << "Stack is empty.\n";
            return;
        }

        cout << "Stack elements (top to bottom): ";
        queue<int> temp = q1;
        while (!temp.empty()) {
            cout << temp.front() << " ";
            temp.pop();
        }
        cout << endl;
    }
};

// ----------------------------
// (a) Menu-driven test
// ----------------------------
int main() {
    StackUsingTwoQueues s;
    int choice, value;

    while (true) {
        cout << "\n--- Stack using Two Queues ---\n";
        cout << "1. Push\n2. Pop\n3. Peek\n4. Display\n5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to push: ";
                cin >> value;
                s.push(value);
                break;

            case 2:
                s.pop();
                break;

            case 3:
                s.peek();
                break;

            case 4:
                s.display();
                break;

            case 5:
                return 0;

            default:
                cout << "Invalid choice! Try again.\n";
        }
    }
}
