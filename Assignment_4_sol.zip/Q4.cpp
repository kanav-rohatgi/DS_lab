#include <iostream>
#include <queue>
using namespace std;

#define MAX 256  // For all ASCII characters

void firstNonRepeating(string str) {
    queue<char> q;
    int freq[MAX] = {0};  // frequency array

    cout << "Output: ";
    for (char ch : str) {
        // Count frequency of the character
        freq[ch]++;

        // Push current character into queue
        q.push(ch);

        // Remove characters from front which are repeating
        while (!q.empty() && freq[q.front()] > 1) {
            q.pop();
        }

        // Check front of queue for the first non-repeating character
        if (q.empty())
            cout << "-1 ";
        else
            cout << q.front() << " ";
    }
    cout << endl;
}

int main() {
    string input;
    cout << "Enter characters (without spaces): ";
    cin >> input;

    firstNonRepeating(input);
    return 0;
}
