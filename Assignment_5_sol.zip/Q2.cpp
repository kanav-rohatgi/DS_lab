#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = nullptr;
    }
};

class SinglyLinkedList {
    Node* head;

public:
    SinglyLinkedList() {
        head = nullptr;
    }

    // Insert at end
    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == nullptr) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != nullptr)
            temp = temp->next;
        temp->next = newNode;
    }

    // Count occurrences of key and delete them
    void countAndDeleteAll(int key) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        int count = 0;

        // Remove occurrences from the beginning
        while (head != nullptr && head->data == key) {
            Node* temp = head;
            head = head->next;
            delete temp;
            count++;
        }

        // Remove occurrences from the rest of the list
        Node* current = head;
        Node* prev = nullptr;

        while (current != nullptr) {
            if (current->data == key) {
                Node* temp = current;
                prev->next = current->next;
                current = current->next;
                delete temp;
                count++;
            } else {
                prev = current;
                current = current->next;
            }
        }

        cout << "Count: " << count << endl;
        cout << "Updated Linked List: ";
        display();
    }

    // Display the linked list
    void display() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }
        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->data;
            if (temp->next != nullptr)
                cout << "->";
            temp = temp->next;
        }
        cout << endl;
    }
};

// ---------------------
// Main function
// ---------------------
int main() {
    SinglyLinkedList list;
    int n, val, key;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter list elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        list.insertAtEnd(val);
    }

    cout << "Enter key to delete: ";
    cin >> key;

    list.countAndDeleteAll(key);

    return 0;
}
