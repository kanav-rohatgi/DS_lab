#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = nullptr;
    }
};

class SinglyLinkedList {
    Node* head;

public:
    SinglyLinkedList() {
        head = nullptr;
    }

    // (a) Insertion at the beginning
    void insertAtBeginning(int val) {
        Node* newNode = new Node(val);
        newNode->next = head;
        head = newNode;
        cout << val << " inserted at the beginning.\n";
    }

    // (b) Insertion at the end
    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newNode;
        }
        cout << val << " inserted at the end.\n";
    }

    // (c) Insertion before or after a specific node
    void insertBeforeAfter(int val, int key, bool insertAfter) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* newNode = new Node(val);

        // Insert before head
        if (!insertAfter && head->data == key) {
            newNode->next = head;
            head = newNode;
            cout << val << " inserted before " << key << ".\n";
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;

        while (temp != nullptr && temp->data != key) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Node " << key << " not found.\n";
            delete newNode;
            return;
        }

        if (insertAfter) {
            newNode->next = temp->next;
            temp->next = newNode;
            cout << val << " inserted after " << key << ".\n";
        } else {
            newNode->next = temp;
            if (prev)
                prev->next = newNode;
            cout << val << " inserted before " << key << ".\n";
        }
    }

    // (d) Deletion from the beginning
    void deleteFromBeginning() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }
        Node* temp = head;
        head = head->next;
        cout << "Deleted node: " << temp->data << endl;
        delete temp;
    }

    // (e) Deletion from the end
    void deleteFromEnd() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }
        if (head->next == nullptr) {
            cout << "Deleted node: " << head->data << endl;
            delete head;
            head = nullptr;
            return;
        }

        Node* temp = head;
        while (temp->next->next != nullptr)
            temp = temp->next;

        cout << "Deleted node: " << temp->next->data << endl;
        delete temp->next;
        temp->next = nullptr;
    }

    // (f) Deletion of a specific node
    void deleteSpecificNode(int key) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        if (head->data == key) {
            Node* temp = head;
            head = head->next;
            cout << "Deleted node: " << temp->data << endl;
            delete temp;
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;

        while (temp != nullptr && temp->data != key) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Node " << key << " not found.\n";
            return;
        }

        prev->next = temp->next;
        cout << "Deleted node: " << temp->data << endl;
        delete temp;
    }

    // (g) Search for a node and display its position
    void searchNode(int key) {
        Node* temp = head;
        int pos = 1;

        while (temp != nullptr) {
            if (temp->data == key) {
                cout << "Node " << key << " found at position " << pos << ".\n";
                return;
            }
            temp = temp->next;
            pos++;
        }

        cout << "Node " << key << " not found in the list.\n";
    }

    // (h) Display all node values
    void display() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Node* temp = head;
        cout << "Linked List: ";
        while (temp != nullptr) {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }
};

// ------------------------
// Menu-driven main program
// ------------------------
int main() {
    SinglyLinkedList list;
    int choice, value, key;
    bool after;

    while (true) {
        cout << "\n--- Singly Linked List Operations ---\n";
        cout << "1. Insert at Beginning\n";
        cout << "2. Insert at End\n";
        cout << "3. Insert Before/After a Node\n";
        cout << "4. Delete from Beginning\n";
        cout << "5. Delete from End\n";
        cout << "6. Delete Specific Node\n";
        cout << "7. Search Node\n";
        cout << "8. Display List\n";
        cout << "9. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> value;
                list.insertAtBeginning(value);
                break;

            case 2:
                cout << "Enter value: ";
                cin >> value;
                list.insertAtEnd(value);
                break;

            case 3:
                cout << "Enter value to insert: ";
                cin >> value;
                cout << "Enter node value to insert before/after: ";
                cin >> key;
                cout << "Insert after (1) or before (0)? ";
                cin >> after;
                list.insertBeforeAfter(value, key, after);
                break;

            case 4:
                list.deleteFromBeginning();
                break;

            case 5:
                list.deleteFromEnd();
                break;

            case 6:
                cout << "Enter node value to delete: ";
                cin >> key;
                list.deleteSpecificNode(key);
                break;

            case 7:
                cout << "Enter value to search: ";
                cin >> key;
                list.searchNode(key);
                break;

            case 8:
                list.display();
                break;

            case 9:
                cout << "Exiting program.\n";
                return 0;

            default:
                cout << "Invalid choice! Try again.\n";
        }
    }
}
