#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Function to perform arithmetic operations
int applyOperation(int a, int b, char op) {
    switch (op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        case '^': {
            int result = 1;
            for (int i = 0; i < b; i++) result *= a;
            return result;
        }
        default: return 0;
    }
}

// Function to evaluate postfix expression
int evaluatePostfix(string expr) {
    stack<int> s;

    for (char ch : expr) {
        // If operand (digit), push to stack
        if (isdigit(ch)) {
            s.push(ch - '0');  // convert char to int
        }
        // If operator, pop two elements and apply operation
        else {
            int val2 = s.top(); s.pop();
            int val1 = s.top(); s.pop();

            int result = applyOperation(val1, val2, ch);
            s.push(result);
        }
    }

    // Final result on top of stack
    return s.top();
}

int main() {
    string expr;
    cout << "Enter a postfix expression (e.g., 23*54*+9-): ";
    cin >> expr;

    int result = evaluatePostfix(expr);
    cout << "Result = " << result << endl;

    return 0;
}
